self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8069dc9c884a114eb21fb9047f877ac4",
    "url": "./index.html"
  },
  {
    "revision": "87a2397fce7852190c25",
    "url": "./static/css/2.aab795e9.chunk.css"
  },
  {
    "revision": "e7b6d4f0d5b0b3c59c7e",
    "url": "./static/css/main.ad64fa35.chunk.css"
  },
  {
    "revision": "87a2397fce7852190c25",
    "url": "./static/js/2.9106fb51.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.9106fb51.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e7b6d4f0d5b0b3c59c7e",
    "url": "./static/js/main.920e24bb.chunk.js"
  },
  {
    "revision": "ca8051aa2fe5b3ef84c3",
    "url": "./static/js/runtime-main.673723db.js"
  },
  {
    "revision": "38d31f021763e26dd065ad99bc82db23",
    "url": "./static/media/GenSenMaruGothicTW-Bold.38d31f02.ttf"
  },
  {
    "revision": "07f157b0382876060c0bedc15c171767",
    "url": "./static/media/ic_title_0.07f157b0.png"
  },
  {
    "revision": "bb52eed9c00d358818794bdbabcd3c7b",
    "url": "./static/media/ic_title_1.bb52eed9.png"
  },
  {
    "revision": "53ceec7c9049f9d798ad0c1219af84ac",
    "url": "./static/media/ic_title_2.53ceec7c.png"
  },
  {
    "revision": "8b9770a3ca29072e87d9f234cdab7541",
    "url": "./static/media/ic_title_3.8b9770a3.png"
  },
  {
    "revision": "3570f03c76da8a315297713f36b29d82",
    "url": "./static/media/pic_withdraw_topbg_d.3570f03c.png"
  }
]);